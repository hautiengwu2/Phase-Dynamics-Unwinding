function [decomp] = PDU(yC, Hz, compN, over, D, eps, IFmethod, SPINC)


decomp = zeros(compN, length(yC)) ;

% flip to remove the boundary effect
yC = [yC fliplr(yC)];

% apply P_+ to get the holomorphic signal
mask = ones(1, length(yC)) ;
mask(length(yC)/2+1:end) = 0 ;

fC = ifft(fft(yC).*mask) ;


for  ll = 1: compN

    % get one component (use pass=2, which gives one component)
    [HighC, LowC, BC, GC, B_phaseC, B_phase_derC, B_prodC] =...
        BKdecomp(fC, 2, length(fC), over, D, eps, IFmethod) ;


    decomp(ll, :) = B_prodC(1, 1:end/2) .* LowC(2, 1:end/2) ;

    comp = B_prodC(1, :) .* LowC(2, :) ;

    if SPINC > 0
        XN = transpose(comp) ;
        ydenoiseR = zeros(length(XN), round(SPINC*Hz/2)*2 + 1 );
        ydenoiseI = zeros(length(XN), round(SPINC*Hz/2)*2 + 1 );
        for nn = -round(SPINC*Hz/2)*2: round(SPINC*Hz/2)*2
            yshift = circshift(real(XN),[0 nn]);
            [yd,cyd] = wdenoise(yshift);
            ydenoiseR(:,nn+round(SPINC*Hz/2)*2+1) = circshift(yd,[0, -nn]);
            yshift = circshift(imag(XN),[0 nn]);
            [yd,cyd] = wdenoise(yshift);
            ydenoiseI(:,nn+round(SPINC*Hz/2)*2+1) = circshift(yd,[0, -nn]);
        end
        comp = transpose(mean(ydenoiseR+sqrt(-1)*ydenoiseI, 2)) ;
    end

    fC = fC - comp ;
    
end
