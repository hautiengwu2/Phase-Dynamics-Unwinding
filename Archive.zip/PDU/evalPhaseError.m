function [Qerr] = evalPhaseError(truecomp, estimated, Hz)

N = length(truecomp) ;

Qerr = inf ;
for ss = 1: 4
    tmp = mod((ss-1)*pi/2+phase(transpose(estimated) .* conj(truecomp)), 2*pi) - (ss-1)*pi/2 ;
    tmp = tmp(Hz+1: N-Hz) - median(tmp(Hz+1: N-Hz)) ;
    if norm(tmp) < Qerr
        Qerr = norm(tmp) ;
    end
end