function [decomp] = winPDU(x, Hz, WIN, compN, over, D, eps, IFmethod)


% start to run windowed PDU (phase dynamics unwrapping) analysis
% you can play with parameters: LEN, BDRY, HOP, PATCHBDRY ...
LEN = round(WIN*Hz) ;
BDRY = round(LEN/4) ;

% generate truncation window
MASK = ones(1, LEN) ;
MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

% this parameter describes how long we jump (HOP should be less than
% LEN-BDRY*2)
HOP = (LEN-BDRY*2)/2 ;
PATCHBDRY = (LEN-BDRY*2) - HOP ;

% generate patching window
MASK2 = ones(1, LEN-BDRY*2) ;
MASK2(1:PATCHBDRY) = sin(pi*linspace(0,1,PATCHBDRY)/2).^2 ;
MASK2(length(MASK2):-1:length(MASK2)-PATCHBDRY+1) = sin(pi*linspace(0,1,PATCHBDRY)/2).^2 ;

MASK2L = ones(1, LEN-BDRY*2) ;
MASK2L(length(MASK2):-1:length(MASK2)-PATCHBDRY+1) = sin(pi*linspace(0,1,PATCHBDRY)/2).^2 ;

MASK2R = ones(1, LEN-BDRY*2) ;
MASK2R(1:PATCHBDRY) = sin(pi*linspace(0,1,PATCHBDRY)/2).^2 ;


% final results
%final1 = zeros(size(x)) ;
%final2 = zeros(size(x)) ;
%final3 = zeros(size(x)) ;
decomp = zeros(compN, length(x)) ;


% for debugging (it should be a constant function 1 except the first and the
% last BDRY.
W = zeros(size(x)) ;


% Gaussian window (another choice, not used)
%MASK = exp(-(([1:LEN]-(LEN/2))/512).^2) ;



% number of windows (sacrifice the boundary of the first window and
% the last part of insufficient length) -- need to be updated by extrapolation
NHOP = floor((length(x) - BDRY*2 - (LEN-BDRY*2-HOP)) / HOP) ;


for  ll = 1: compN

    tmp = zeros(1, length(x)) ;
    
    for jj = 1: NHOP

        % time index for truncation
        idx = (1:LEN) + (jj-1)*HOP ;

        % time index for the patching
        INDEX1 = (1: LEN-BDRY*2) + BDRY ;
        INDEX2 = (1: LEN-BDRY*2) + BDRY + (jj-1)*HOP ;

        % generate the truncated signal (Truncation step)
        y = (x(idx) - mean(x(idx))) .* MASK ;


        y = [y fliplr(y)] ;
        y = hilbert(y) ;

        y1 = ifft(fft(y)) ;





        % run BDK (or now PDU) algorithm in each truncated signal
        % directly call BKdecomp for pass = compN+1 to get compN components
        % ideally, we shall change this code to follow PDU.m to get one
        % component at a time, and iterate.
        [High, Low, B, G, B_phase, B_phase_der, B_prod] = ...
            BKdecomp(y1, 2, length(y1), over, D, eps, IFmethod) ;

        % get the decomposed signal
        f = Low(2, 1:end/2) .* B_prod(1, 1:end/2) ;

        % for debug
        W(INDEX2) = W(INDEX2) + MASK2 ;

        % generate the final signal (patching step)
        if jj == 1
            tmp(INDEX2) = tmp(INDEX2) + f(INDEX1) .* MASK2L ;
        elseif jj == NHOP
            tmp(INDEX2) = tmp(INDEX2) + f(INDEX1) .* MASK2R ;
        else
            tmp(INDEX2) = tmp(INDEX2) + f(INDEX1) .* MASK2 ;
        end

    end

    decomp(ll, :) = tmp ;
    x = x - real(tmp) ;
end
