clear ; close all ;

addpath('/Users/hautiengwu/Dropbox/code/NonLinearTFanalysis20200515') ;
addpath('/Users/hautiengwu/Dropbox/code/common') ;
scrsz = get(groot,'ScreenSize');


% when WFS=1, plot Figure 4. when WSF=0, reproduce the 2nd part of section
% 3.3

snrdb = 10 ;
WSF = 0 ;



% generate the simulated data
% high sampling rate to avoid sampling issue
Hz = 512 ;
time = [1/Hz:1/Hz:16]' ;
N = length(time) ;


% these parameters are for BKD
% nb passes for reconstruction
% get pass-1 components
compN = 2 ;

% Ratio for oversampling (over=1 no oversampling)
over = 16 ;

% Degree of polynomial for approximation (D=1 => cste)
BKD_D = 5 ;

% Value of epsilon as a threshold for f.
eps = 1e-4 ;

% four methods to evaluate phase and IF
% method 1: directly with B phase
% method 2: using Grad(B) / B
% method 3: same way but using Fourier decomposition
IFmethod = 3 ;


iterNO = 1 ;

ERRBKD = zeros(iterNO, 2) ;
ERRwinBKD = zeros(iterNO, 2) ;

initstate(1111) ;


for rNO = 1: iterNO

    % the amplitude modulation of the simulated signal
    am1 = smooth(cumsum(randn(N,1)) ./ Hz, 1.5*Hz, 'loess') ;
    am1 = 2 + am1 ./ max(abs(am1)) ;
    am2 = smooth(cumsum(randn(N,1)) ./ Hz, 1.3*Hz, 'loess') ;
    am2 = 1.7 + am2 ./ max(abs(am2)) ;



    % the instantaneous frequency of the simulated signal
    % guarantee that the IFs do not overlap
    while 1
        if1 = smooth(cumsum(randn(N,1)) ./ Hz, 2.2*Hz, 'loess') ;
        if1 = 2+pi + 2.5 * if1 ./ max(abs(if1)) ;
        if2 = smooth(cumsum(randn(N,1)) ./ Hz, 2*Hz, 'loess') ;
        if2 = 8 + 3 * if2 ./ max(abs(if2)) ;
        if min(if2 - if1) > 1 & min(if2) < max(if1) - 0.5
            break
        end
    end

    phi1 = cumsum(if1) / Hz ;
    phi2 = cumsum(if2) / Hz ;



    % generate random shapes
    s1 = zeros(size(am1)) ;
    s2 = zeros(size(am2)) ;
    if WSF == 1
        a1 = triu(randn(5)) ; a1 = sum(a1.^2,1) ./ [1:5] ; a1(1) = a1(1)+0.5 ;
        a2 = triu(randn(5)) ; a2 = sum(a2.^2,1) ./ [1:5] ; a2(1) = a2(1)+0.5 ;
    else
        a1 = [1 0 0 0 0] ;
        a2 = a1 ;
    end
    b1 = rand(5,1) * 2 * pi ;
    b2 = rand(5,1) * 2 * pi ;
    for sidx = 1: 5
        s1 = s1 + a1(sidx)*cos(2*pi*sidx*phi1+b1(sidx)) ;
        s2 = s2 + a2(sidx)*cos(2*pi*sidx*phi2+b2(sidx)) ;
    end

    truefund1 = exp(sqrt(-1)*(2*pi*phi1+b1(1))) ;
    truefund2 = exp(sqrt(-1)*(2*pi*phi2+b2(1))) ;

    % the simulated signal.
    f1 = am1 .* s1 ./ norm(a1) ;
    f2 = am2 .* s2 ./ norm(a2) ;
    clean = f1 + f2 ;






    % add noise (Gaussian white noise)

    sigma = sqrt( var(clean)*10.^( -snrdb /10 ) );
    noise = randn(N,1) ;
    noise = sigma * noise ;
    fprintf(['snrdb = ',num2str(snrdb),'\n']) ;



    % simulated observed time series
    xm = clean + noise ;







    %======================== apply BKD

    % original PDU
    PDUdecomp = PDU(xm', Hz, compN, over, BKD_D, eps, IFmethod, 0) ;
    nasPDUdecomp = PDUdecomp ;
    for qq = 1: 299
        NA = exp(randn(size(xm))/1) ; NA = NA ./ mean(NA) ;
        [PDUdecomp0] = PDU(NA'.*xm', Hz, compN, over, BKD_D, eps, IFmethod, 0) ;
        nasPDUdecomp = nasPDUdecomp + PDUdecomp0 ;
    end
    nasPDUdecomp = nasPDUdecomp / 300 ;




    % windowed PDU (use 2 second window)
    WIN = 2 ;
    winPDUdecomp = winPDU(xm', Hz, WIN, compN, over, BKD_D, eps, IFmethod) ;
    naswinPDUdecomp = winPDUdecomp ;
    for qq = 1: 299
        NA = exp(randn(size(xm))/1) ; NA = NA ./ mean(NA) ;
        [winPDUdecomp0] = winPDU(NA'.*xm', Hz, WIN, compN, over, BKD_D, eps, IFmethod) ;
        naswinPDUdecomp = naswinPDUdecomp + winPDUdecomp0 ;
    end
    naswinPDUdecomp = naswinPDUdecomp / 300 ;




    if 1
        figure ;
        subplot(411)
        plot(time, f1, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(PDUdecomp(1, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('PDU')
        subplot(412)
        plot(time, f1, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(nasPDUdecomp(1, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('nasPDU')


        subplot(413)
        plot(time, f1, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(winPDUdecomp(1, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('winPDU')
        subplot(414)
        plot(time, f1, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(naswinPDUdecomp(1, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; xlabel('Time (s)') ; set(gca,'fontsize', 24) ; ylabel('naswinPDU')

        figure ;
        subplot(411)
        plot(time, f2, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(PDUdecomp(2, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('PDU')
        subplot(412)
        plot(time, f2, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(nasPDUdecomp(2, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('nasPDU')


        subplot(413)
        plot(time, f2, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(winPDUdecomp(2, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; set(gca,'xtick',[]) ; set(gca,'fontsize', 24) ; ylabel('winPDU')
        subplot(414)
        plot(time, f2, 'color', [.6 .6 .6], 'linewidth', 1) ; hold on ;
        plot(time, real(naswinPDUdecomp(2, :)), 'b', 'linewidth', 2) ;
        axis([-inf inf -inf inf]) ; xlabel('Time (s)') ; set(gca,'fontsize', 24) ; ylabel('naswinPDU')
    end



    


    % evaluate the phase as a metric
    BKDf1 = PDUdecomp(1, 300:end-299) ./ abs(PDUdecomp(1, 300:end-299)) ; 
    BKDf2 = PDUdecomp(2, 300:end-299) ./ abs(PDUdecomp(2, 300:end-299)) ;

    ERRBKD(rNO, 1) = evalPhaseError(truefund1(300:end-299), BKDf1, Hz) ;
    ERRBKD(rNO, 2) = evalPhaseError(truefund2(300:end-299), BKDf2, Hz) ;

    winBKDf1 = winPDUdecomp(1, 300:end-299) ./ abs(winPDUdecomp(1, 300:end-299)) ; 
    winBKDf2 = winPDUdecomp(2, 300:end-299) ./ abs(winPDUdecomp(2, 300:end-299)) ;

    ERRwinBKD(rNO, 1) = evalPhaseError(truefund1(300:end-299), winBKDf1, Hz) ;
    ERRwinBKD(rNO, 2) = evalPhaseError(truefund2(300:end-299), winBKDf2, Hz) ;


end

fprintf(['BKD: ' num2str(median(ERRBKD(:,1)./sqrt(N))) '+-' num2str(mad(ERRBKD(:,1)./sqrt(N))) '\n'])
fprintf(['BKD: ' num2str(median(ERRBKD(:,2)./sqrt(N))) '+-' num2str(mad(ERRBKD(:,2)./sqrt(N))) '\n'])

fprintf(['winBKD: ' num2str(median(ERRwinBKD(:,1)./sqrt(N))) '+-' num2str(mad(ERRwinBKD(:,1)./sqrt(N))) '\n'])
fprintf(['winBKD: ' num2str(median(ERRwinBKD(:,2)./sqrt(N))) '+-' num2str(mad(ERRwinBKD(:,2)./sqrt(N))) '\n'])

