function [Poisson] = getPoisson(F, C)
% find Poisson integral at all values saved in C
% where F is f(e^{i\theta})
Poisson = zeros(size(C)) ;

% Theta = the discretization of S^1
Theta = exp(2*pi*sqrt(-1)*(1:length(F))'/length(F)) ;
tau = 2*pi/length(F) ;


for qq = 1: length(C)

    % C(qq) = re^{i\theta}, \theta \in [0,2\pi)
    r = abs(C(qq)) ;

    % Used Poisson integral formula:
    % U(re^{i\theta}) = \frac{1}{2pi} * tau * \sum f.*\frac{1-r^2}{1-2*r*cc+r^2},
    % where tau is the sampling period over [0, 2\pi) and re^{i\theta}\in D
    if 1-r < 0

        keyboard

    elseif 1-r < 1e-6

        % angle(C(qq)) / 2/pi \in [0,1), used to count the index
        idx = round(length(F) * mod(angle(C(qq)), 2*pi) / 2/pi) ;
        Poisson(qq) = F(idx) ;

    elseif 1-r >= 1e-6

        z = C(qq) ./ r ; % this is e^{i\theta}
        cc = real(z*conj(Theta)) ; % this is cos(\theta-t)
        Pll = (1-r.^2) ./ max(1e-10, 1 - 2*r*cc + r.^2) ;

        % another formula
        % Pll = real( (1 + r*z*conj(Theta)) ./ (1 - r*z*conj(Theta)) ) ; 
        Poisson(qq) = Pll' * F * (tau ./ (2*pi)) ;

    elseif r == 0

        Poisson(qq) = mean(F)/2/pi ;

    end


    %if abs(Poisson(qq)) > 1
    %    keyboard
    %end
end
