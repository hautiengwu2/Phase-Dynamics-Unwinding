close all ; clear
scrsz = get(0,'ScreenSize') ;

t = linspace(0, 2*pi, 15000) ;

FONTSIZE = 32 ;




%%
alpha1 = 0.2 * (1 + 1i) / sqrt(2) ;
f1 = (exp(1i*t) - alpha1) ./ (1 - conj(alpha1)*exp(1i*t)) ;
IF1 = (1 - abs(alpha1).^2) ./ abs(exp(1i*t)-alpha1).^2 ;



h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f1), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha1)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f_{\alpha_1}(t))$','Interpreter', 'latex')
text(0, 1.3, '(a)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF1, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha1)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$\phi''_{\alpha_1}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha1), imag(alpha1),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha1)+0.05, imag(alpha1)+0.01, '$\times 1$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B1alpha1.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');



%%
f14 = f1 .* f1 .* f1 .* f1 ;

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f14), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha1)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^4_{\alpha_1}(t))$','Interpreter', 'latex')
text(0, 1.3, '(b)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF1*4, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha1)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$4\phi''_{\alpha_1}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha1), imag(alpha1),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha1)+0.05, imag(alpha1)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B4alpha1.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');



 



%%
alpha2 = 0.7 * (-2 + 1i) / sqrt(5) ;
f2 = (exp(1i*t) - alpha2) ./ (1 - conj(alpha2)*exp(1i*t)) ;
IF2 = (1 - abs(alpha2).^2) ./ abs(exp(1i*t)-alpha2).^2 ;

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f2), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f_{\alpha_2}(t))$','Interpreter', 'latex')
text(0, 1.3, '(c)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF2, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$\phi''_{\alpha_2}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha2), imag(alpha2),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha2)+0.05, imag(alpha2)+0.01, '$\times 1$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B1alpha2.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');

 


%%

f24 = f2 .* f2 .* f2 .* f2 ;


h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f24), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^4_{\alpha_2}(t))$','Interpreter', 'latex')
text(0, 1.3, '(d)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, 4*IF2, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$4\phi''_{\alpha_2}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha2), imag(alpha2),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha2)+0.05, imag(alpha2)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B4alpha2.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');

 



%%
alpha3 = 0.9 * (1 - 2i) / sqrt(5) ;
f3 = (exp(1i*t) - alpha3) ./ (1 - conj(alpha3)*exp(1i*t)) ;
IF3 = (1 - abs(alpha3).^2) ./ abs(exp(1i*t)-alpha3).^2 ;


h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f3), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f_{\alpha_3}(t))$','Interpreter', 'latex')
text(0, 1.3, '(e)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF3, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$\phi''_{\alpha_3}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha3), imag(alpha3),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha3)+0.05, imag(alpha3)+0.01, '$\times 1$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B1alpha3.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');


 



%%
f34 = f3 .* f3 .* f3 .* f3 ;


h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f34), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^4_{\alpha_3}(t))$','Interpreter', 'latex')
text(0, 1.3, '(f)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, 4*IF3, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$4\phi''_{\alpha_3}(t)$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha3), imag(alpha3),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha3)+0.05, imag(alpha3)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B4alpha3.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');


 





%%
f44 = f24 .* f34 ;
IF4 = IF2*4 + IF3*4 ;



h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f44), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^4_{\alpha_2}f^4_{\alpha_3})$','Interpreter', 'latex')
text(0, 1.3, '(g)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF4, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$4(\phi''_{\alpha_2}+\phi''_{\alpha_3})$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha2), imag(alpha2),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha2)+0.05, imag(alpha2)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
plot(real(alpha3), imag(alpha3),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha3)+0.05, imag(alpha3)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B4alpha2alpha3.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');






%%
f46 = f24 .* f2 .* f2 .* f34 .* f3  ;
IF5 = IF2*6 + IF3*5 ;


h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f46), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^6_{\alpha_2}f^5_{\alpha_3})$','Interpreter', 'latex')
text(0, 1.3, '(h)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF5, 'b', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$6\phi''_{\alpha_2}+5\phi''_{\alpha_3}$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha2), imag(alpha2),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha2)+0.05, imag(alpha2)+0.01, '$\times 6$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
plot(real(alpha3), imag(alpha3),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
text(real(alpha3)+0.05, imag(alpha3)+0.01, '$\times 5$', 'fontsize', FONTSIZE,...
    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B6alpha2alpha3.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');



%%

alpha4 = 0.9 * (0.9 - sqrt(5-0.9^2)*1i) / sqrt(5) ;
f4 = (exp(1i*t) - alpha4) ./ (1 - conj(alpha4)*exp(1i*t)) ;
IF4 = (1 - abs(alpha4).^2) ./ abs(exp(1i*t)-alpha4).^2 ;

alpha5 = 0.9 * (1.12 - sqrt(5-1.12^2)*1i) / sqrt(5) ;
f5 = (exp(1i*t) - alpha5) ./ (1 - conj(alpha5)*exp(1i*t)) ;
IF5 = (1 - abs(alpha5).^2) ./ abs(exp(1i*t)-alpha5).^2 ;

f46q = f24 .* f3 .* f3 .* f4 .* f5  ;
IF46q = IF2*4 + IF3*2 + IF4 + IF5 ;

f46p = f24 .* f3 .* f3 .* f3 .* f3  ;
IF46p = IF2*4 + IF3*4 ;

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.85]) ;
subplot(3,5,1:4)
plot(t/2/pi, real(f46p), 'color', [.7 .7 .7], 'linewidth', 4) ; hold on ; 
plot(t/2/pi, real(f46q), 'r', 'linewidth', 2) ;  
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha4)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha5)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f^4_{\alpha_2}f^2_{\alpha_3}f_{\alpha_4}f_{\alpha_5})$','Interpreter', 'latex')
text(0, 1.3, '(i)', 'fontsize', 1.2*FONTSIZE) ;

subplot(3,5,6:9)
plot(t/2/pi, IF46p, 'color', [.7 .7 .7], 'linewidth', 4) ; hold on ; 
plot(t/2/pi, IF46q, 'b', 'linewidth', 2) ; hold on ; 
plot(mod(angle(alpha2)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha4)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot(mod(angle(alpha5)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$4\phi''_{\alpha_2}+2\phi''_{\alpha_3}\\+\phi''_{\alpha_4}+\phi''_{\alpha_5}$','Interpreter', 'latex')

subplot(3,5,[5 10])
plot(t/pi-1, sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(t/pi-1, -sqrt(1-(t/pi-1).^2), 'k', 'linewidth', 3) ; hold on ; 
plot(0, 0, 'k.', 'markersize', 20, 'linewidth', 3) ;
plot(real(alpha2), imag(alpha2),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
%text(real(alpha2)+0.05, imag(alpha2)+0.01, '$\times 4$', 'fontsize', FONTSIZE,...
%    'Interpreter', 'latex', 'color', 'b') ;
plot(real(alpha3), imag(alpha3),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
%text(real(alpha3)+0.05, imag(alpha3)+0.01, '$\times 3$', 'fontsize', FONTSIZE,...
%    'Interpreter', 'latex', 'color', 'b') ;
plot(real(alpha4), imag(alpha4),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
%text(real(alpha4)+0.05, imag(alpha4)+0.01, '$\times 1$', 'fontsize', FONTSIZE,...
%    'Interpreter', 'latex', 'color', 'b') ;
plot(real(alpha5), imag(alpha5),...
    'b.', 'markersize', 32, 'linewidth', 3) ;
%text(real(alpha5)+0.05, imag(alpha5)+0.01, '$\times 1$', 'fontsize', FONTSIZE,...
%    'Interpreter', 'latex', 'color', 'b') ;
axis image ;  set(gca,'fontsize', FONTSIZE) ; 
exportgraphics(h1, 'B46q.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');

subplot(3,5,1:4) ; xlim([0.701 0.899])
subplot(3,5,6:9) ; xlim([0.701 0.899])
subplot(3,5,[5 10]) ; xlim([0.25 0.65]) ; ylim([-0.95 -0.55]) 
exportgraphics(h1, 'B46qZoom.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');


