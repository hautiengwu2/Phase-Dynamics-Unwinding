clear ; close all ;

addpath('/Users/hautiengwu/Dropbox/code/common')
addpath('/Users/hautiengwu/Dropbox/___course/2025 sinica summer school/Matlab code/PDU') ;
warning('off', 'all');
scrsz = get(0,'ScreenSize') ;


load('/Users/hautiengwu/Dropbox/database/Capnobase/0009_8min');


ppg = signal.pleth.y ;
fs = param.samplingrate.pleth ;
co2_ = signal.co2.y ;
fs_co2 = param.samplingrate.co2 ;
ecg_ = signal.ecg.y ;
fs_e = param.samplingrate.ecg ;






% collect 7500-7700 s signal. 6500 is good. 4500 is BAD
% TODO: change point detection
START = 0 ;
TIMELEN = 60 ;

tt_co2 = START*fs_co2+1: (START+TIMELEN)*fs_co2 ;
co2 = co2_(tt_co2);
tt_ecg = START*fs_e+1: (START+TIMELEN)*fs_e;
ecgs = ecg_(tt_ecg);



rlocsf = RpeakUltraLong(ecgs, fs_e) ;

%Wn = 0.5 / (fs / 2);
%[b, a] = butter(4, Wn, 'high');
x0 = ppg - mean(ppg) ;
%x0 = filtfilt(b, a, ppg) ;
tt = START*fs+1: (START+TIMELEN)*fs ;
x0 = x0(tt) - mean(x0(tt)) ;






%% run BKD


% these parameters are for BKD
% nb passes for reconstruction
pass = 2 ;

% Ratio for oversampling (over=1 no oversampling)
over = 24 ;

% Degree of polynomial for approximation (D=1 => cste)
BKD_D = 5 ;

% Value of epsilon as a threshold for f.
eps = 1e-4 ;

% four methods to evaluate phase and IF
% method 1: directly with B phase
% method 2: using Grad(B) / B
% method 3: same way but using Fourier decomposition
IFmethod = 3 ;


t = (1:length(x0))'/fs ;
N = length(t) ;
T = t(end) ;

y = [x0' fliplr(x0')] ;
y = hilbert(y) ;

mask = ones(1, length(y)) ;
mask(length(y)/2+1:end) = 0 ;
y1 = ifft(fft(y)) ;

% run BDK (or now PDU) algorithm in each truncated signal
t1 = tic ;
[High, Low, B, G, B_phase, B_phase_der, B_prod] = BKdecomp(y1,...
    4, length(y1), over, BKD_D, eps, IFmethod) ;
toc(t1) ;

% get the decomposed signal
f1 = Low(2, 1:end/2) .* B_prod(1, 1:end/2) ;
f2 = Low(3, 1:end/2) .* B_prod(2, 1:end/2) ;
f3 = Low(4, 1:end/2) .* B_prod(3, 1:end/2) ;
recon = real(f1+f2+f3) ;
time = (1:length(f1)) / fs ;




%% run windowed BKD

WIN = 2 ;
t1 = tic ;
xmext = [flipud(x0(1:WIN*fs)); x0; flipud(x0(end-WIN*fs+1: end))] ;

if 1
    [decomp] = winPDU(xmext', fs, WIN, 6, over, BKD_D, eps, IFmethod) ;
    toc(t1) ;
    f1win = real(decomp(1, WIN*fs+1:end-WIN*fs)) ;
    f2win = real(decomp(2, WIN*fs+1:end-WIN*fs)) ;
    f3win = real(decomp(3, WIN*fs+1:end-WIN*fs)) ;
else
    [decomp1] = winPDU(xmext', fs, WIN, 2, over, BKD_D, eps, IFmethod) ;
    f1win = real(decomp1(1, WIN*fs+1:end-WIN*fs)) ;
    [decomp2] = winPDU(xmext'-real(decomp1(1, :)),...
        fs, WIN, 2, over, BKD_D, eps, IFmethod) ;
    f2win = real(decomp2(1, WIN*fs+1:end-WIN*fs)) ;
    [decomp3] = winPDU(xmext'-real(decomp1(1, :))-real(decomp2(1, :)),...
        fs, WIN, 2, over, BKD_D, eps, IFmethod) ;
    f3win = real(decomp3(1, WIN*fs+1:end-WIN*fs)) ;
end

reconwin = f1win + f2win + f3win ;
reconwin2 = sum(real(decomp(:, WIN*fs+1:end-WIN*fs)), 1) ;


%%
h1 = figure;
MMM = quantile(abs(x0), .99) * 1.2 ;
plot(time, x0, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
plot(time, real(f1)- MMM*1.2, 'r', 'linewidth', 2) ;
plot(time(rlocsf), real(f1(rlocsf))- MMM*1.2, 'bx', 'linewidth', 2, 'markersize', 16) ;
plot(time, real(f2)- MMM*2.1, 'm', 'linewidth', 2) ;
plot(time, real(f3)- MMM*2.8, 'k', 'linewidth', 2) ;
set(gca, 'fontsize', 20) ; axis tight ; xlabel('Time (s)') ;
plot(time, recon, 'b', 'linewidth', 2) ; hold on ;
xlim([5 25]) ;

exportgraphics(h1, 'PPG_PDU.pdf',...
'ContentType', 'vector', 'BackgroundColor','none');

h1 = figure; 
MMM = quantile(abs(x0), .99) * 1.2 ;
plot(time, x0, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
plot(time, f1win - MMM*1.2, 'r', 'linewidth', 2) ;
plot(time(rlocsf), real(f1win(rlocsf))- MMM*1.2, 'bx', 'linewidth', 2, 'markersize', 16) ;
plot(time, f2win - MMM*2.1, 'm', 'linewidth', 2) ;
plot(time(rlocsf), real(f2win(rlocsf))- MMM*2.1, 'bx', 'linewidth', 2, 'markersize', 16) ;
plot(time, f3win - MMM*2.8, 'k', 'linewidth', 2) ;
plot(time(rlocsf), real(f3win(rlocsf))- MMM*2.8, 'bx', 'linewidth', 2, 'markersize', 16) ;
set(gca, 'fontsize', 20) ; axis tight ; xlabel('Time (s)') ;
plot(time, reconwin, 'b', 'linewidth', 2) ; hold on ;
xlim([5 25]) ;

exportgraphics(h1, 'PPG_winPDU.pdf',...
'ContentType', 'vector', 'BackgroundColor','none');


h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ;
plot(time, x0-reconwin', 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
plot(time, x0-reconwin2', 'b', 'linewidth', 2) ; 
%plot(time, std(x0-reconwin') * co2 ./ std(co2) - 2*std(x0-reconwin'),...
%    'r', 'linewidth', 2) ;
plot(time, co2, 'r', 'linewidth', 2) ;
set(gca, 'fontsize', 20) ; axis tight ; xlabel('Time (s)') ;
xlim([5 25]) ;

exportgraphics(h1, 'ReconResp_winPDU.pdf',...
'ContentType', 'vector', 'BackgroundColor','none');
