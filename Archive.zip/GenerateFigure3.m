close all ; clear
scrsz = get(0,'ScreenSize') ;
addpath('/Users/hautiengwu/Dropbox/___working tex since 20221228/_WORKING Raphy BKD/code') ;
Hz = 30000 ;
t = linspace(0, 2*pi, Hz) ;

FONTSIZE = 26 ;





%%
alpha3 = 0.9 * (1 - 2i) / sqrt(5) ;
f3 = (exp(1i*t) - alpha3) ./ (1 - conj(alpha3)*exp(1i*t)) ;
IF3 = (1 - abs(alpha3).^2) ./ abs(exp(1i*t)-alpha3).^2 ;

f35 = f3 .* f3 .* f3 .* f3 .* f3 ;


xtic = linspace(-1, 1, 600) ;
ytic = linspace(-1, 1, 600) ;
[X,Y] = meshgrid(xtic, ytic);
Z = X + sqrt(-1)*Y ;

R = sqrt(X.^2 + Y.^2) ; 
idxR = R <= 1 ;


if 0 % this is for the debug getPoissonv2 purpose
    t1 = tic ;
    % evaluate Poisson integral pointwisely
    [tmp] = getPoissonv2(transpose(f35), Z(idx)) ;
    f35P = nan(size(Z)) ;
    f35P(idx) = tmp ;
    toc(t1)


    t1 = tic ;
    tmp = (Z(idx) - alpha3).^5 ./ (1 - conj(alpha3)*Z(idx)).^5 ;
    z35 = nan(size(Z)) ;
    z35(idx) = tmp ;
    toc(t1)


    subplot(121)
    imagesc(X(1,:), Y(:,1)', abs(z35)) ; axis xy ; axis image ;

    subplot(122)
    imagesc(X(1,:), Y(:,1)', abs(f35P)) ; axis xy ; axis image ;
    
end


% a short window
pL = 0.09 ;
LEN = round(pL*Hz) ;
BDRY = round(LEN/8) ;

% generate truncation window
MASK = ones(1, LEN) ;
MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

idx = round((1+angle(alpha3)/2/pi - pL/2)*Hz): round((1+angle(alpha3)/2/pi - pL/2)*Hz)+LEN-1 ;
winf35 = f35(idx) .* MASK ;


%% evaluate Poisson integral pointwisely
t1 = tic ;
[tmp] = getPoissonv2(transpose(winf35), Z(idxR)) ;
% numerically correct erraneous evaluation
tmp(abs(tmp)>1) = tmp(abs(tmp)>1) ./ abs(tmp(abs(tmp)>1)) ;
tmp2 = tmp ;
tmp2(abs(tmp2) > 0.005) = 1 ; 
tmp2(abs(tmp2) <= 0.005) = 0 ; 
winf35P = nan(size(Z)) ;
winf35P(idxR) = tmp ;
winf3501 = nan(size(Z)) ;
winf3501(idxR) = tmp2 ;
toc(t1)


if 0
    % a longer window
    pL = 0.15 ;
    LEN = round(pL*Hz) ;
    BDRY = round(LEN/8) ;

    % generate truncation window
    MASK = ones(1, LEN) ;
    MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
    MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

    idx = round((1+angle(alpha3)/2/pi - pL/2)*Hz): round((1+angle(alpha3)/2/pi - pL/2)*Hz)+LEN-1 ;
    win2f35 = f35(idx) .* MASK ;


    %xmforroot = hilbert(win2f35) ;
    %[allroots2, roots2] = comp_root_exp(xmforroot);


    t1 = tic ;
    % evaluate Poisson integral pointwisely
    xmforroot = hilbert(win2f35) ;
    [tmp] = getPoissonv2(transpose(xmforroot), Z(idxR)) ;
    tmp(abs(tmp)>1) = tmp(abs(tmp)>1) ./ abs(tmp(abs(tmp)>1)) ;
    win2f35P = nan(size(Z)) ;
    win2f35P(idxR) = tmp ;
    toc(t1)

end








%%
h1 = figure('Position',[1 scrsz(4) scrsz(3)*.85 scrsz(4)]) ;
subplot(4,3,1:3)
plot(t/2/pi, real(f35), 'r', 'linewidth', 4) ; hold on ; 
plot(mod(angle(alpha3)/2/pi, 1), -1,...
    'bx', 'markersize', 18, 'linewidth', 3) ;
plot([1+angle(alpha3)/2/pi, 1+angle(alpha3)/2/pi]-0.05, [-1 1], 'color', [.7 .7 .7], 'linewidth', 3)
plot([1+angle(alpha3)/2/pi, 1+angle(alpha3)/2/pi]+0.05, [-1 1], 'color', [.7 .7 .7], 'linewidth', 3)
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
ylabel('$\texttt{Re}(f(t))$','Interpreter', 'latex')

subplot(4,3,4:6)
plot(linspace(0,1, length(winf35)), winf35, 'b', 'linewidth', 4) ; hold on ; 
axis tight ; set(gca,'fontsize', FONTSIZE) ; 
xlabel('$t$', 'interpreter', 'latex') ; 
ylabel('$\texttt{Re}(f_w(t))$','Interpreter', 'latex')

subplot(4,3,[7 10])
imagesc(X(1,:), Y(:,1)', abs(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(4,3,[8 11])
imagesc(X(1,:), Y(:,1)', angle(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(4,3,[9 12])
imagesc(X(1,:), Y(:,1)', abs(winf3501)) ; axis xy ; axis image ; hold on ;
colorbar ; set(gca,'fontsize', FONTSIZE) ; 

%cmap = parula(256); % an easy way
%cmap = flipud(cbrewer2('div','RdBu',256)); % Requires cbrewer toolbox
cmap = cbrewer2('div','Reds',256) ; % Requires cbrewer toolbox
colormap(cmap); 
clim([0 1]) ;

exportgraphics(h1, 'WindowedB5alpha3.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');


 





%% next, show the stability to windows

FONTSIZE = 18 ;


pL = 0.1 ;
LEN = round(pL*Hz) ;
BDRY = round(LEN/8) ;

% generate truncation window
MASK = ones(1, LEN) ;
MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

idx = round((1+angle(alpha3)/2/pi - pL/2)*Hz): round((1+angle(alpha3)/2/pi - pL/2)*Hz)+LEN-1 ;
winf35 = f35(idx) .* MASK ;


% evaluate Poisson integral pointwisely
t1 = tic ;
[tmp] = getPoissonv2(transpose(winf35), Z(idxR)) ;
% numerically correct erraneous evaluation
tmp(abs(tmp)>1) = tmp(abs(tmp)>1) ./ abs(tmp(abs(tmp)>1)) ;
tmp2 = tmp ;
tmp2(abs(tmp2) > 0.005) = 1 ; 
tmp2(abs(tmp2) <= 0.005) = 0 ; 
winf35P = nan(size(Z)) ;
winf35P(idxR) = tmp ;
winf3501 = nan(size(Z)) ;
winf3501(idxR) = tmp2 ;
toc(t1)


h1 = figure('Position',[1 scrsz(4) scrsz(3)*.65 scrsz(4)]) ;

subplot(6,3,[1 4])
imagesc(X(1,:), Y(:,1)', abs(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[2 5])
imagesc(X(1,:), Y(:,1)', angle(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[3 6])
imagesc(X(1,:), Y(:,1)', abs(winf3501)) ; axis xy ; axis image ; hold on ;
colorbar ; set(gca,'fontsize', FONTSIZE) ; 







pL = 0.09 ;
LEN = round(pL*Hz) ;
BDRY = round(LEN/6) ;

% generate truncation window
MASK = ones(1, LEN) ;
MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

idx = round((1+angle(alpha3)/2/pi - pL/2)*Hz): round((1+angle(alpha3)/2/pi - pL/2)*Hz)+LEN-1 ;
winf35 = f35(idx) .* MASK ;


% evaluate Poisson integral pointwisely
t1 = tic ;
[tmp] = getPoissonv2(transpose(winf35), Z(idxR)) ;
% numerically correct erraneous evaluation
tmp(abs(tmp)>1) = tmp(abs(tmp)>1) ./ abs(tmp(abs(tmp)>1)) ;
tmp2 = tmp ;
tmp2(abs(tmp2) > 0.005) = 1 ; 
tmp2(abs(tmp2) <= 0.005) = 0 ; 
winf35P = nan(size(Z)) ;
winf35P(idxR) = tmp ;
winf3501 = nan(size(Z)) ;
winf3501(idxR) = tmp2 ;
toc(t1)

subplot(6,3,[7 10])
imagesc(X(1,:), Y(:,1)', abs(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[8 11])
imagesc(X(1,:), Y(:,1)', angle(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[9 12])
imagesc(X(1,:), Y(:,1)', abs(winf3501)) ; axis xy ; axis image ; hold on ;
colorbar ; set(gca,'fontsize', FONTSIZE) ; 

%cmap = parula(256); % an easy way
%cmap = flipud(cbrewer2('div','RdBu',256)); % Requires cbrewer toolbox
cmap = cbrewer2('div','Reds',256) ; % Requires cbrewer toolbox
colormap(cmap); 
clim([0 1]) ;






pL = 0.07 ;
LEN = round(pL*Hz) ;
BDRY = round(LEN/9) ;

% generate truncation window
MASK = ones(1, LEN) ;
MASK(1:BDRY) = sin(pi*linspace(0,1,BDRY)/2).^2 ;
MASK(LEN:-1:LEN-BDRY+1) = sin(pi*linspace(0,1,BDRY)/2).^2 ;

idx = round((1+angle(alpha3)/2/pi - pL/2)*Hz): round((1+angle(alpha3)/2/pi - pL/2)*Hz)+LEN-1 ;
winf35 = f35(idx) .* MASK ;


% evaluate Poisson integral pointwisely
t1 = tic ;
[tmp] = getPoissonv2(transpose(winf35), Z(idxR)) ;
% numerically correct erraneous evaluation
tmp(abs(tmp)>1) = tmp(abs(tmp)>1) ./ abs(tmp(abs(tmp)>1)) ;
tmp2 = tmp ;
tmp2(abs(tmp2) > 0.005) = 1 ; 
tmp2(abs(tmp2) <= 0.005) = 0 ; 
winf35P = nan(size(Z)) ;
winf35P(idxR) = tmp ;
winf3501 = nan(size(Z)) ;
winf3501(idxR) = tmp2 ;
toc(t1)

subplot(6,3,[13 16])
imagesc(X(1,:), Y(:,1)', abs(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[14 17])
imagesc(X(1,:), Y(:,1)', angle(winf35P)) ; axis xy ; axis image ; colorbar
set(gca,'fontsize', FONTSIZE) ; 

subplot(6,3,[15 18])
imagesc(X(1,:), Y(:,1)', abs(winf3501)) ; axis xy ; axis image ; hold on ;
colorbar ; set(gca,'fontsize', FONTSIZE) ; 

%cmap = parula(256); % an easy way
%cmap = flipud(cbrewer2('div','RdBu',256)); % Requires cbrewer toolbox
cmap = cbrewer2('div','Reds',256) ; % Requires cbrewer toolbox
colormap(cmap); 
clim([0 1]) ;




exportgraphics(h1, 'WindowedQcomparison.pdf',...
    'ContentType', 'vector', 'BackgroundColor','none');