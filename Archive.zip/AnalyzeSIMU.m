clear; close all;

addpath('/Users/hautiengwu/Dropbox/code/common')
addpath('/Users/hautiengwu/Dropbox/___course/2025 sinica summer school/Matlab code/PDU') ;
warning('off', 'all');
scrsz = get(0,'ScreenSize') ;


WSF = 0 ;
HIGH2nd = 1 ; % larger 2nd IMT
CUMSUM = 0 ;
NOISE = 0 ;
NAS = 1 ;
snrdb = 5 ;
    
if NOISE
    fprintf(['NOISY data with snrdb = ',num2str(snrdb),'\n']) ;
end




% these parameters are for BKD
% nb passes for reconstruction
pass = 2 ;

% Ratio for oversampling (over=1 no oversampling)
over = 16 ;

% Degree of polynomial for approximation (D=1 => cste)
BKD_D = 5 ;

% Value of epsilon as a threshold for f.
eps = 1e-4 ;

% four methods to evaluate phase and IF
% method 1: directly with B phase
% method 2: using Grad(B) / B
% method 3: same way but using Fourier decomposition
IFmethod = 1 ;




fs = 512 ;
time = (1/fs:1/fs:16)' ;
N = length(time) ;
T = time(end) ;


simuNO = 2 ;

AMerr = zeros(simuNO, 2) ;
winAMerr = zeros(simuNO, 2) ;
PHIerr = zeros(simuNO, 2) ;
winPHIerr = zeros(simuNO, 2) ;
winRecerr = zeros(simuNO, 1) ;
Recerr = zeros(simuNO, 1) ;


rng(123) ;


for lll = 1: simuNO

    waitbar(lll/simuNO)

    if HIGH2nd
        alpha1 = 0.1 ; alpha2 = 0.1 ; xi1 = pi  ; xi2 = 12 ;
    else
        alpha1 = 1 ; alpha2 = 1 ; xi1 = pi + 2 ; xi2 = 8 ;
    end

    % the amplitude modulation of the simulated signal
    am1 = smooth(cumsum(randn(N,1)) ./ fs, 2.2*fs, 'loess') ;
    am1 = 2 * (1 + alpha1*am1 ./ max(abs(am1))/2) ;
    am2 = smooth(cumsum(randn(N,1)) ./ fs, 2*fs, 'loess') ;
    am2 = 0.8 * (1 + alpha2*am2 ./ max(abs(am2)) /2) ; % *0.1 is needed for CUMSUM

    if HIGH2nd % swap
        tmp = am1 ; am1 = am2 ; am2 = tmp ; clear tmp ;     
    end

    % the instantaneous frequency of the simulated signal
    % guarantee that the IFs do not overlap
    while 1
        if1 = smooth(cumsum(randn(N,1)) ./ fs, 2.2*fs, 'loess') ;
        if1 = xi1 + 2.5 * if1 ./ max(abs(if1)) ;
        if2 = smooth(cumsum(randn(N,1)) ./ fs, 2*fs, 'loess') ;
        if2 = xi2 + 3 * if2 ./ max(abs(if2)) ;
        if min(if2 - if1) > 0.5 %&& min(if2) < max(if1) - 0.5
            break
        end
    end

    phi1 = cumsum(if1) / fs ;
    phi2 = cumsum(if2) / fs ;



    % generate random shapes
    s1 = zeros(size(am1)) ;
    s2 = zeros(size(am2)) ;
    if WSF == 1
        a1 = triu(randn(5)) ; a1 = sum(a1.^2,1) ./ (1:5) ; a1(1) = a1(1)+0.5 ;
        a2 = triu(randn(5)) ; a2 = sum(a2.^2,1) ./ (1:5) ; a2(1) = a2(1)+0.5 ;
        a1 = a1 ./ norm(a1) ;
        a2 = a2 ./ norm(a2) ;
        b1 = rand(5,1) * 2 * pi ;
        b2 = rand(5,1) * 2 * pi ;
    else
        a1 = [1 0 0 0 0] ;
        a2 = a1 ;
        b1 = [0 0 0 0 0] ;
        b2 = b1 ;
    end

    for sidx = 1: 5
        s1 = s1 + a1(sidx)*cos(2*pi*sidx*phi1+b1(sidx)) ;
        s2 = s2 + a2(sidx)*cos(2*pi*sidx*phi2+b2(sidx)) ;
    end

    trues1 = exp(sqrt(-1)*(2*pi*phi1+b1(1))) ;
    trues2 = exp(sqrt(-1)*(2*pi*phi2+b2(1))) ;

    % the simulated signal.
    truef1 = am1 .* s1 ;
    truef2 = am2 .* s2 ;
    clean = truef1 + truef2 ;






    % add noise (Gaussian white noise)
    if NOISE        
        sigma = sqrt( var(clean)*10.^( -snrdb /10 ) );
        noise = randn(N,1) ;
        noise = sigma * noise ;
    else
        noise = zeros(size(clean)) ;
    end
    


    % simulated observed time series
    xm = clean + noise ;

    if NOISE
        [b,a] = butter(6, 50/(fs/2), 'low');
        xm = filtfilt(b,a, xm) ;
    end




    xm0 = xm ;

    if CUMSUM
        xm = cumsum(resample(xm0, fs*10, fs)) / fs / 10 ; 
        %xm = xm - mean(xm) ;
        %xm = cumsum(xm) / fs / 10 ;
        xm = xm(1:10:end) ;
        XX = [ones(length(xm), 1) (1:length(xm))'/fs/10] ; YY = xm ;
        beta = (XX'*XX) \ (XX'*YY) ;
        xm = xm - XX*beta ;
    end

    


    % run windowed PDU
    WIN = 0.5 ;
    SAFEINT = 1.5*WIN*fs+1:N-1.5*WIN*fs ;

    t1 = tic ;
    xmext = [flipud(xm(1:WIN*fs)); xm; flipud(xm(end-WIN*fs+1: end))] ;
    [decomp] = winPDU(xmext', fs, WIN, 4, over, BKD_D, eps, IFmethod) ; % input=row
    f1win = decomp(1, WIN*fs+1:end-WIN*fs) ;
    f2win = decomp(2, WIN*fs+1:end-WIN*fs) ;



    if NAS > 1
        for nidx = 2:NAS
            tmp = xm + 0.005*sigma*randn(size(xm)) ;
            [tmp] = winPDU(tmp', fs, WIN, 4, over, BKD_D, eps, IFmethod) ;
            f1win = [f1win; tmp(1, :)] ;
            f2win = [f2win; tmp(2, :)] ;
        end
        f1win = median(f1win, 1) ;
        f2win = median(f2win, 1) ;
    end
    toc(t1)
    


    if CUMSUM
        f1win = derivative((1:length(f1win))/fs, f1win) ;
        f2win = derivative((1:length(f2win))/fs, f2win) ;
    end

    f1win = f1win(SAFEINT) ;
    f2win = f2win(SAFEINT) ;
    ERRwin = xm0(SAFEINT)' - real(f1win+f2win) ;
    reconwin = real(f1win + f2win) ;

    winAMerr(lll, 1) = norm(am1(SAFEINT)' - abs(f1win)) ./ norm(am1(SAFEINT)) ;
    winAMerr(lll, 2) = norm(am2(SAFEINT)' - abs(f2win)) ./ norm(am2(SAFEINT)) ;
    winPHIerr(lll, 1) = std(angle(trues1(SAFEINT)' .* f1win)) ;
    winPHIerr(lll, 2) = std(angle(trues2(SAFEINT)' .* f2win)) ;
    winRecerr(lll) = norm(ERRwin) ./ norm(xm0(SAFEINT)) ;



    % run pure PDU
    y = [xm' fliplr(xm')] ;
    y = hilbert(y) ;

    mask = ones(1, length(y)) ;
    mask(length(y)/2+1:end) = 0 ;
    y1 = ifft(fft(y)) ;

    % run BDK algorithm in each truncated signal
    t1 = tic ;
    [High, Low, B, G, B_phase, B_phase_der, B_prod] = BKdecomp(y1,...
        4, length(y1), over, BKD_D, eps, IFmethod) ;
    

    % get the decomposed signal
    f1 = Low(2, 1:end/2) .* B_prod(1, 1:end/2) ;
    f2 = Low(3, 1:end/2) .* B_prod(2, 1:end/2) ;
    
    if NAS > 1

        for nidx = 2: NAS
            tmp = xm + 0.005*sigma*randn(size(xm)) ;
            y = [tmp' fliplr(tmp')] ;
            y = hilbert(y) ;

            mask = ones(1, length(y)) ;
            mask(length(y)/2+1:end) = 0 ;
            y1 = ifft(fft(y)) ;

            % run BDK algorithm in each truncated signal
            [High, Low, B, G, B_phase, B_phase_der, B_prod] = BKdecomp(y1,...
                4, length(y1), over, BKD_D, eps, IFmethod) ;

            % get the decomposed signal
            f1tmp = Low(2, 1:end/2) .* B_prod(1, 1:end/2) ;
            f2tmp = Low(3, 1:end/2) .* B_prod(2, 1:end/2) ;

            f1 = [f1; f1tmp] ;
            f2 = [f2; f2tmp] ;
        end

        f1 = median(f1, 1) ; f2 = median(f2, 1) ;

    end

    
    if CUMSUM
        f1 = derivative((1:length(f1))/fs, f1) ;
        f2 = derivative((1:length(f2))/fs, f2) ;
    end


toc(t1) ;



    f1 = f1(SAFEINT) ;
    f2 = f2(SAFEINT) ;
    ERR = xm0(SAFEINT)' - real(f1+f2) ;
    recon = real(f1 + f2) ;

    AMerr(lll, 1) = norm(am1(SAFEINT)' - abs(f1)) ./ norm(am1(SAFEINT)) ;
    AMerr(lll, 2) = norm(am2(SAFEINT)' - abs(f2)) ./ norm(am2(SAFEINT)) ;
    PHIerr(lll, 1) = std(angle(trues1(SAFEINT)' .* f1)) ;
    PHIerr(lll, 2) = std(angle(trues2(SAFEINT)' .* f2)) ;
    Recerr(lll) = norm(ERR) ./ norm(xm0(SAFEINT)) ;

end




%%
h0 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/3]) ;
subplot(151) 
MM = quantile([AMerr(:,1); winAMerr(:, 1)], .99) ;
mm = quantile([AMerr(:,1); winAMerr(:, 1)], .01) ;
plot(AMerr(:,1), winAMerr(:,1), 'r.') ; xlabel('PDU') ; ylabel('windowed PDU') ;
set(gca, 'fontsize', 16) ; axis image ; axis([mm MM mm MM])

subplot(152) 
MM = quantile([AMerr(:,2); winAMerr(:, 2)], .99) ;
mm = quantile([AMerr(:,2); winAMerr(:, 2)], .01) ;
plot(AMerr(:,2), winAMerr(:,2), 'r.') ; xlabel('PDU') ; ylabel('windowed PDU') ;
set(gca, 'fontsize', 16) ; axis image ; axis([mm MM mm MM])

subplot(153) 
MM = quantile([PHIerr(:,1); winPHIerr(:, 1)], .99) ;
mm = quantile([PHIerr(:,1); winPHIerr(:, 1)], .01) ;
plot(PHIerr(:,1), winPHIerr(:,1), 'b.') ; xlabel('PDU') ; ylabel('windowed PDU') ;
set(gca, 'fontsize', 16) ; axis image ; axis([mm MM mm MM])

subplot(154) 
MM = quantile([PHIerr(:,2); winPHIerr(:, 2)], .99) ;
mm = quantile([PHIerr(:,2); winPHIerr(:, 2)], .01) ;
plot(PHIerr(:,2), winPHIerr(:,2), 'b.') ; xlabel('PDU') ; ylabel('windowed PDU') ;
set(gca, 'fontsize', 16) ; axis image ; axis([mm MM mm MM]) ;

subplot(155) 
MM = quantile([Recerr(:); winRecerr(:)], .99) ;
mm = quantile([Recerr(:); winRecerr(:)], .01) ;
plot(Recerr, winRecerr, 'k.') ; xlabel('PDU') ; ylabel('windowed PDU') ;
set(gca, 'fontsize', 16) ; axis image ; axis([mm MM mm MM])

exportgraphics(h0, ['SUMMARY_High2nd' num2str(HIGH2nd) 'PDU' num2str(CUMSUM)...
    '_' num2str(NOISE) '_' num2str(NAS) '.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');




%% plot results

time = time(SAFEINT) ;
xm = xm(SAFEINT) ;
xm0 = xm0(SAFEINT) ;
truef1 = truef1(SAFEINT) ;
truef2 = truef2(SAFEINT) ;

MMM = quantile(abs(xm0), .99) * 1.2 ;
h1 = figure('Position',[1 scrsz(4) scrsz(3)/2 scrsz(4)*2/3]) ;
plot(time, xm0, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
plot(time, real(truef1)- MMM*1.6, 'color', [.7 .7 .7], 'linewidth', 2) ;
plot(time, real(f1)- MMM*1.6, 'r', 'linewidth', 2) ;
plot(time, real(truef2)- MMM*2.8, 'color', [.7 .7 .7], 'linewidth', 2) ;
plot(time, real(f2)- MMM*2.8, 'b', 'linewidth', 2) ;
plot(time, real(ERR)- MMM*3.4, 'm', 'linewidth', 2) ;
set(gca, 'fontsize', 18) ; axis tight ; xlabel('Time (s)') ;
plot(time, recon, 'b', 'linewidth', 1) ; xlim([5 7.5])

exportgraphics(h1, ['High2nd' num2str(HIGH2nd) 'PDU' num2str(CUMSUM)...
    '_' num2str(NOISE) '_' num2str(NAS) '.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');


h2 = figure('Position',[1 scrsz(4) scrsz(3)/2 scrsz(4)*2/3]) ;
plot(time, xm0, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
plot(time, real(truef1)- MMM*1.6, 'color', [.7 .7 .7], 'linewidth', 2) ;
plot(time, real(f1win)- MMM*1.6, 'r', 'linewidth', 2) ;
plot(time, real(truef2)- MMM*2.8, 'color', [.7 .7 .7], 'linewidth', 2) ;
plot(time, real(f2win)- MMM*2.8, 'b', 'linewidth', 2) ;
plot(time, real(ERRwin)- MMM*3.4, 'm', 'linewidth', 2) ;
set(gca, 'fontsize', 18) ; axis tight ; xlabel('Time (s)') ;
plot(time, reconwin, 'b', 'linewidth', 1) ; xlim([5 7.5])

exportgraphics(h2, ['High2nd' num2str(HIGH2nd) 'winPDU' num2str(CUMSUM)...
    '_' num2str(NOISE) '_' num2str(NAS) '.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');


disp([AMerr(1, 1) AMerr(1, 2) PHIerr(1, 1) PHIerr(1, 2) Recerr(1)]) 
disp([winAMerr(1, 1) winAMerr(1, 2) winPHIerr(1, 1) winPHIerr(1, 2) winRecerr(1)]) 
